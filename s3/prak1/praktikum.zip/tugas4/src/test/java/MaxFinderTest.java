import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import com.example.MaxFinder;

public class MaxFinderTest {

    @Test
    public void testPositiveNumbers() {
        assertEquals(3, MaxFinder.findMax(1, 2, 3), "Max of 1, 2, 3 should be 3");
        assertEquals(3, MaxFinder.findMax(3, 2, 1), "Max of 3, 2, 1 should be 3");
    }

    @Test
    public void testNegativeNumbers() {
        assertEquals(-1, MaxFinder.findMax(-1, -2, -3), "Max of -1, -2, -3 should be -1");
    }

    @Test
    public void testMixedNumbers() {
        assertEquals(1, MaxFinder.findMax(0, 0, 1), "Max of 0, 0, 1 should be 1");
    }

    @Test
    public void testAllEqualNumbers() {
        assertEquals(5, MaxFinder.findMax(5, 5, 5), "Max of 5, 5, 5 should be 5");
    }

    @Test
    public void testZeroNumbers() {
        assertEquals(0, MaxFinder.findMax(0, 0, 0), "Max of 0, 0, 0 should be 0");
    }
}
