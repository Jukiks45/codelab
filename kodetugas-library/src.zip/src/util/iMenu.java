package util;

public interface iMenu {
    void menu();
}
